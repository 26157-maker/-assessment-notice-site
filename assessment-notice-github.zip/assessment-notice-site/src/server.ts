import "dotenv/config";
import express from "express";
import session from "express-session";
import pg from "pg";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { OAuth2Client } from "google-auth-library";
import crypto from "node:crypto";

const { Pool } = pg;
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(__dirname, "..", "public");
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL?.includes("localhost") ? false : { rejectUnauthorized: false } });
const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

declare module "express-session" {
  interface SessionData {
    user?: { id: string; email: string; name: string; role: "teacher" | "admin"; approvalStatus: string };
  }
}

app.disable("x-powered-by");
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  secret: process.env.SESSION_SECRET || "development-only-change-this-secret",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.COOKIE_SECURE === "true",
    maxAge: 1000 * 60 * 60 * 8
  }
}));
app.use(express.static(publicDir));

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      google_sub TEXT UNIQUE NOT NULL,
      email TEXT NOT NULL,
      display_name TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'teacher' CHECK (role IN ('teacher','admin')),
      approval_status TEXT NOT NULL DEFAULT 'pending'
        CHECK (approval_status IN ('pending','approved','rejected','suspended')),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS classes (
      id SMALLINT PRIMARY KEY,
      grade SMALLINT NOT NULL CHECK (grade BETWEEN 1 AND 3),
      class_number SMALLINT NOT NULL CHECK (class_number BETWEEN 1 AND 8),
      UNIQUE(grade, class_number)
    );
    CREATE TABLE IF NOT EXISTS subjects (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      name TEXT NOT NULL UNIQUE,
      is_active BOOLEAN NOT NULL DEFAULT TRUE
    );
    CREATE TABLE IF NOT EXISTS assessments (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      title TEXT NOT NULL,
      subject_id BIGINT NOT NULL REFERENCES subjects(id),
      description TEXT NOT NULL DEFAULT '',
      materials TEXT NOT NULL DEFAULT '',
      assessment_date DATE NOT NULL,
      due_at DATE,
      created_by UUID NOT NULL REFERENCES users(id),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS assessment_classes (
      assessment_id UUID NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
      class_id SMALLINT NOT NULL REFERENCES classes(id),
      PRIMARY KEY(assessment_id, class_id)
    );
    CREATE TABLE IF NOT EXISTS assessment_attachments (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      assessment_id UUID NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
      original_name TEXT NOT NULL,
      storage_path TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      size_bytes BIGINT NOT NULL,
      uploaded_by UUID NOT NULL REFERENCES users(id),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS audit_logs (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      actor_id UUID REFERENCES users(id),
      action TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_id TEXT NOT NULL,
      details JSONB NOT NULL DEFAULT '{}'::jsonb,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    for (let grade = 1; grade <= 3; grade++) {
      for (let classNo = 1; classNo <= 8; classNo++) {
        const id = (grade - 1) * 8 + classNo;
        await client.query(
          "INSERT INTO classes(id, grade, class_number) VALUES($1,$2,$3) ON CONFLICT DO NOTHING",
          [id, grade, classNo]
        );
      }
    }
    for (const name of ["국어","수학","영어","통합사회","통합과학","한국사","체육","음악","미술","정보","기술·가정","기타"]) {
      await client.query("INSERT INTO subjects(name) VALUES($1) ON CONFLICT(name) DO NOTHING", [name]);
    }
    await client.query("COMMIT");
  } catch (e) {
    await client.query("ROLLBACK");
    throw e;
  } finally { client.release(); }
}

function currentUser(req: express.Request) { return req.session.user; }
function requireLogin(req: express.Request, res: express.Response, next: express.NextFunction) {
  if (!currentUser(req)) return res.status(401).json({ error: "로그인이 필요합니다." });
  next();
}
function requireApproved(req: express.Request, res: express.Response, next: express.NextFunction) {
  const u = currentUser(req);
  if (!u) return res.status(401).json({ error: "로그인이 필요합니다." });
  if (u.role !== "admin" && u.approvalStatus !== "approved") {
    return res.status(403).json({ error: "관리자의 교사 승인이 필요합니다." });
  }
  next();
}
function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const u = currentUser(req);
  if (!u) return res.status(401).json({ error: "로그인이 필요합니다." });
  if (u.role !== "admin") return res.status(403).json({ error: "관리자 권한이 필요합니다." });
  next();
}
async function audit(actorId: string, action: string, targetType: string, targetId: string, details: object = {}) {
  await pool.query(
    "INSERT INTO audit_logs(actor_id,action,target_type,target_id,details) VALUES($1,$2,$3,$4,$5)",
    [actorId, action, targetType, targetId, JSON.stringify(details)]
  );
}

app.get("/api/health", async (_req, res) => {
  try { await pool.query("SELECT 1"); res.json({ ok: true, database: "connected" }); }
  catch { res.status(503).json({ ok: false, database: "unavailable" }); }
});

app.get("/api/auth/me", (req, res) => {
  const u = currentUser(req);
  res.json({ user: u || null, googleConfigured: Boolean(process.env.GOOGLE_CLIENT_ID), googleClientId: process.env.GOOGLE_CLIENT_ID || null });
});

app.post("/api/auth/google", async (req, res) => {
  try {
    if (!process.env.GOOGLE_CLIENT_ID) return res.status(503).json({ error: "Google 로그인 설정이 필요합니다. README를 확인하세요." });
    const credential = String(req.body?.credential || "");
    if (!credential) return res.status(400).json({ error: "Google 인증 토큰이 없습니다." });
    const ticket = await googleClient.verifyIdToken({ idToken: credential, audience: process.env.GOOGLE_CLIENT_ID });
    const payload = ticket.getPayload();
    if (!payload?.sub || !payload.email || !payload.email_verified) return res.status(401).json({ error: "Google 계정을 검증할 수 없습니다." });

    const email = payload.email.toLowerCase();
    const bootstrap = (process.env.BOOTSTRAP_ADMIN_EMAIL || "").toLowerCase();
    let result = await pool.query("SELECT * FROM users WHERE google_sub=$1", [payload.sub]);
    let row;
    if (result.rowCount) {
      row = result.rows[0];
      if (row.email.toLowerCase() !== email) {
        await pool.query("UPDATE users SET email=$1 WHERE id=$2", [email, row.id]);
        row.email = email;
      }
    } else {
      const isBootstrap = bootstrap && email === bootstrap;
      const insert = await pool.query(
        `INSERT INTO users(google_sub,email,display_name,role,approval_status)
         VALUES($1,$2,$3,$4,$5) RETURNING *`,
        [payload.sub, email, payload.name || email, isBootstrap ? "admin" : "teacher", isBootstrap ? "approved" : "pending"]
      );
      row = insert.rows[0];
    }
    if (row.approval_status === "suspended" || row.approval_status === "rejected") {
      return res.status(403).json({ error: row.approval_status === "suspended" ? "계정 권한이 정지되었습니다." : "교사 승인 신청이 거절되었습니다." });
    }
    req.session.user = {
      id: row.id, email: row.email, name: row.display_name,
      role: row.role, approvalStatus: row.approval_status
    };
    res.json({ user: req.session.user });
  } catch (e) {
    console.error("Google auth error", e);
    res.status(401).json({ error: "Google 로그인 검증에 실패했습니다. OAuth 설정을 확인하세요." });
  }
});

app.post("/api/auth/logout", (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("connect.sid");
    res.json({ ok: true });
  });
});

app.post("/api/teacher/apply", requireLogin, async (req, res) => {
  const u = currentUser(req)!;
  if (u.role === "admin" || u.approvalStatus === "approved") return res.json({ ok: true, status: u.approvalStatus });
  res.json({ ok: true, status: u.approvalStatus, message: "교사 승인 대기 중입니다. 관리자에게 승인을 요청하세요." });
});

app.get("/api/subjects", async (_req, res) => {
  const r = await pool.query("SELECT id,name FROM subjects WHERE is_active=true ORDER BY name");
  res.json(r.rows);
});

app.get("/api/assessments", async (req, res) => {
  try {
    const grade = Number(req.query.grade);
    const classNo = Number(req.query.class);
    if (!Number.isInteger(grade) || grade < 1 || grade > 3 || !Number.isInteger(classNo) || classNo < 1 || classNo > 8) {
      return res.status(400).json({ error: "유효한 학년과 반을 선택하세요." });
    }
    const params: any[] = [grade, classNo];
    let where = "c.grade=$1 AND c.class_number=$2";
    if (req.query.month && /^\d{4}-\d{2}$/.test(String(req.query.month))) {
      params.push(String(req.query.month) + "-01");
      where += ` AND a.assessment_date >= $${params.length}::date AND a.assessment_date < ($${params.length}::date + INTERVAL '1 month')`;
    }
    if (req.query.subject) {
      params.push(Number(req.query.subject));
      where += ` AND a.subject_id=$${params.length}`;
    }
    if (req.query.q) {
      params.push("%" + String(req.query.q).slice(0, 100).replace(/[%_]/g, "\\$&") + "%");
      where += ` AND (a.title ILIKE $${params.length} OR a.description ILIKE $${params.length})`;
    }
    if (req.query.from && /^\d{4}-\d{2}-\d{2}$/.test(String(req.query.from))) {
      params.push(String(req.query.from)); where += ` AND a.assessment_date >= $${params.length}::date`;
    }
    if (req.query.to && /^\d{4}-\d{2}-\d{2}$/.test(String(req.query.to))) {
      params.push(String(req.query.to)); where += ` AND a.assessment_date <= $${params.length}::date`;
    }
    const r = await pool.query(
      `SELECT a.id,a.title,a.description,a.materials,a.assessment_date,
              a.due_at,a.created_by,a.created_at,a.updated_at,
              s.id AS subject_id,s.name AS subject,
              ARRAY_AGG(DISTINCT jsonb_build_object('grade',cc.grade,'class_number',cc.class_number)) AS classes,
              COALESCE(json_agg(DISTINCT jsonb_build_object('id',f.id,'name',f.original_name,'mime_type',f.mime_type))
                FILTER (WHERE f.id IS NOT NULL), '[]') AS attachments
       FROM assessments a
       JOIN subjects s ON s.id=a.subject_id
       JOIN assessment_classes ac ON ac.assessment_id=a.id
       JOIN classes c ON c.id=ac.class_id
       JOIN assessment_classes ac2 ON ac2.assessment_id=a.id
       JOIN classes cc ON cc.id=ac2.class_id
       LEFT JOIN assessment_attachments f ON f.assessment_id=a.id
       WHERE ${where}
       GROUP BY a.id,s.id
       ORDER BY COALESCE(a.due_at,a.assessment_date),a.assessment_date`,
      params
    );
    res.json(r.rows);
  } catch (e) {
    console.error(e); res.status(500).json({ error: "일정을 불러오지 못했습니다." });
  }
});

app.get("/api/assessments/:id", async (req, res) => {
  const r = await pool.query(
    `SELECT a.id,a.title,a.description,a.materials,a.assessment_date,a.due_at,
            s.name AS subject,
            COALESCE(json_agg(DISTINCT jsonb_build_object('id',f.id,'name',f.original_name,'mime_type',f.mime_type))
              FILTER (WHERE f.id IS NOT NULL), '[]') AS attachments
     FROM assessments a JOIN subjects s ON s.id=a.subject_id
     LEFT JOIN assessment_attachments f ON f.assessment_id=a.id
     WHERE a.id=$1 GROUP BY a.id,s.name`, [req.params.id]
  );
  if (!r.rowCount) return res.status(404).json({ error: "일정을 찾을 수 없습니다." });
  res.json(r.rows[0]);
});

app.post("/api/assessments", requireApproved, async (req, res) => {
  const u = currentUser(req)!;
  const { title, subjectId, description = "", materials = "", assessmentDate, dueAt = null, classIds } = req.body || {};
  if (!String(title || "").trim() || !Number.isInteger(Number(subjectId)) ||
      !/^\d{4}-\d{2}-\d{2}$/.test(String(assessmentDate)) ||
      !Array.isArray(classIds) || classIds.length < 1 || classIds.length > 24) {
    return res.status(400).json({ error: "제목, 과목, 평가 날짜, 대상 학급을 올바르게 입력하세요." });
  }
  const valid = await pool.query("SELECT id FROM classes WHERE id = ANY($1::smallint[])", [classIds.map(Number)]);
  if (valid.rowCount !== new Set(classIds.map(Number)).size) return res.status(400).json({ error: "대상 학급이 올바르지 않습니다." });
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const created = await client.query(
      `INSERT INTO assessments(title,subject_id,description,materials,assessment_date,due_at,created_by)
       VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
      [String(title).trim().slice(0,200), Number(subjectId), String(description).slice(0,10000), String(materials).slice(0,5000), assessmentDate, dueAt || null, u.id]
    );
    for (const id of [...new Set(classIds.map(Number))]) {
      await client.query("INSERT INTO assessment_classes(assessment_id,class_id) VALUES($1,$2)", [created.rows[0].id, id]);
    }
    await client.query("COMMIT");
    await audit(u.id, "create", "assessment", created.rows[0].id, { title });
    res.status(201).json({ id: created.rows[0].id });
  } catch (e) {
    await client.query("ROLLBACK"); console.error(e); res.status(500).json({ error: "일정을 등록하지 못했습니다." });
  } finally { client.release(); }
});

app.patch("/api/assessments/:id", requireApproved, async (req, res) => {
  const u = currentUser(req)!;
  const existing = await pool.query("SELECT * FROM assessments WHERE id=$1", [req.params.id]);
  if (!existing.rowCount) return res.status(404).json({ error: "일정을 찾을 수 없습니다." });
  if (u.role !== "admin" && existing.rows[0].created_by !== u.id) return res.status(403).json({ error: "본인이 등록한 일정만 수정할 수 있습니다." });
  const old = existing.rows[0];
  const { title, subjectId, description = "", materials = "", assessmentDate, dueAt = null, classIds } = req.body || {};
  if (!String(title || "").trim() || !Number.isInteger(Number(subjectId)) || !/^\d{4}-\d{2}-\d{2}$/.test(String(assessmentDate)) || !Array.isArray(classIds) || classIds.length < 1 || classIds.length > 24) {
    return res.status(400).json({ error: "입력값을 확인하세요." });
  }
  const valid = await pool.query("SELECT id FROM classes WHERE id = ANY($1::smallint[])", [classIds.map(Number)]);
  if (valid.rowCount !== new Set(classIds.map(Number)).size) return res.status(400).json({ error: "대상 학급이 올바르지 않습니다." });
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query(
      `UPDATE assessments SET title=$1,subject_id=$2,description=$3,materials=$4,assessment_date=$5,due_at=$6,updated_at=NOW() WHERE id=$7`,
      [String(title).trim().slice(0,200), Number(subjectId), String(description).slice(0,10000), String(materials).slice(0,5000), assessmentDate, dueAt || null, req.params.id]
    );
    await client.query("DELETE FROM assessment_classes WHERE assessment_id=$1", [req.params.id]);
    for (const id of [...new Set(classIds.map(Number))]) await client.query("INSERT INTO assessment_classes(assessment_id,class_id) VALUES($1,$2)", [req.params.id, id]);
    await client.query("COMMIT");
    await audit(u.id, "update", "assessment", req.params.id, { previousTitle: old.title, title });
    res.json({ ok: true });
  } catch (e) { await client.query("ROLLBACK"); console.error(e); res.status(500).json({ error: "수정에 실패했습니다." }); }
  finally { client.release(); }
});

app.delete("/api/assessments/:id", requireApproved, async (req, res) => {
  const u = currentUser(req)!;
  const existing = await pool.query("SELECT * FROM assessments WHERE id=$1", [req.params.id]);
  if (!existing.rowCount) return res.status(404).json({ error: "일정을 찾을 수 없습니다." });
  if (u.role !== "admin" && existing.rows[0].created_by !== u.id) return res.status(403).json({ error: "본인이 등록한 일정만 삭제할 수 있습니다." });
  await pool.query("DELETE FROM assessments WHERE id=$1", [req.params.id]);
  await audit(u.id, "delete", "assessment", req.params.id, { title: existing.rows[0].title });
  res.json({ ok: true });
});

app.get("/api/admin/teachers", requireAdmin, async (_req, res) => {
  const r = await pool.query("SELECT id,email,display_name,role,approval_status,created_at FROM users ORDER BY created_at DESC");
  res.json(r.rows);
});

app.patch("/api/admin/teachers/:id", requireAdmin, async (req, res) => {
  const u = currentUser(req)!;
  const { approvalStatus, role } = req.body || {};
  if (!["pending","approved","rejected","suspended"].includes(approvalStatus) || !["teacher","admin"].includes(role)) {
    return res.status(400).json({ error: "유효하지 않은 권한 변경입니다." });
  }
  if (req.params.id === u.id && role !== "admin") return res.status(400).json({ error: "자신의 관리자 권한을 이 화면에서 해제할 수 없습니다." });
  const r = await pool.query("UPDATE users SET approval_status=$1,role=$2 WHERE id=$3 RETURNING id,email,display_name,role,approval_status", [approvalStatus, role, req.params.id]);
  if (!r.rowCount) return res.status(404).json({ error: "사용자를 찾을 수 없습니다." });
  await audit(u.id, "update_role", "user", req.params.id, { approvalStatus, role });
  res.json(r.rows[0]);
});

app.get("/api/admin/audit-logs", requireAdmin, async (_req, res) => {
  const r = await pool.query(
    `SELECT l.id,l.action,l.target_type,l.target_id,l.details,l.created_at,u.email
     FROM audit_logs l LEFT JOIN users u ON u.id=l.actor_id ORDER BY l.created_at DESC LIMIT 200`
  );
  res.json(r.rows);
});

app.use("/api", (_req, res) => res.status(404).json({ error: "API를 찾을 수 없습니다." }));

const port = Number(process.env.PORT || 3000);
initDb().then(() => {
  app.listen(port, "0.0.0.0", () => console.log(`Assessment Notice running on port ${port}`));
}).catch(err => {
  console.error("Database initialization failed. Check DATABASE_URL and PostgreSQL availability.", err);
  process.exit(1);
});
