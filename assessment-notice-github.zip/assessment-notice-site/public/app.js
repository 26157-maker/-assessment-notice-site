const $ = (id) => document.getElementById(id);
const state = { grade: 1, classNo: 1, month: new Date(new Date().getFullYear(), new Date().getMonth(), 1), all: [], filtered: [], subjects: [], user: null };
const weekdays = ["월","화","수","목","금","토","일"];
const pad = n => String(n).padStart(2,"0");
const dateStr = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const parseDate = s => s ? new Date(`${String(s).slice(0,10)}T12:00:00`) : null;
const escapeHtml = s => String(s ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(msg){const el=$("toast");el.textContent=msg;el.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>el.classList.remove("show"),3000);}
function dday(date){if(!date)return null;const a=new Date();a.setHours(0,0,0,0);const b=parseDate(date);b.setHours(0,0,0,0);return Math.round((b-a)/86400000);}
function deadline(a){return a.due_at ? String(a.due_at).slice(0,10) : String(a.assessment_date).slice(0,10);}
function pretty(s){if(!s)return "미정";const d=parseDate(s);return `${d.getFullYear()}.${pad(d.getMonth()+1)}.${pad(d.getDate())}`;}
function getDdayText(n){if(n===0)return "D-Day";if(n>0)return `D-${n}`;return `D+${Math.abs(n)}`;}
function openDialog(id){$(id).showModal();}
function closeDialog(id){$(id).close();}
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>closeDialog(b.dataset.close)));
document.querySelectorAll("dialog").forEach(d=>d.addEventListener("click",e=>{if(e.target===d)d.close();}));
function fillClasses(){
  $("classSelect").innerHTML = Array.from({length:8},(_,i)=>`<option value="${i+1}">${i+1}반</option>`).join("");
  $("classSelect").value = state.classNo;
}
function rememberClass(){try{localStorage.setItem("assessmentClass",JSON.stringify({grade:state.grade,classNo:state.classNo}));}catch{}}
function loadSavedClass(){try{const x=JSON.parse(localStorage.getItem("assessmentClass")||"null");if(x&&x.grade>=1&&x.grade<=3&&x.classNo>=1&&x.classNo<=8){state.grade=x.grade;state.classNo=x.classNo;}}catch{}}
function showDashboard(){
  $("classPicker").hidden=true;$("dashboard").hidden=false;
  $("classTitle").textContent=`${state.grade}학년 ${state.classNo}반`;
  $("selectedLabel").textContent=`${state.grade}학년 ${state.classNo}반`;
  $("gradeSelect").value=state.grade;$("classSelect").value=state.classNo;
  rememberClass(); loadData();
}
function showPicker(){$("dashboard").hidden=true;$("classPicker").hidden=false;$("selectedLabel").textContent="";}
async function api(url,opts={}){
  const r=await fetch(url,{credentials:"same-origin",...opts,headers:{"Content-Type":"application/json",...(opts.headers||{})}});
  const data=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error(data.error||"요청에 실패했습니다.");
  return data;
}
async function loadSubjects(){
  try{state.subjects=await api("/api/subjects");}
  catch{state.subjects=[];}
  $("subjectFilter").innerHTML='<option value="">모든 과목</option>'+state.subjects.map(s=>`<option value="${s.id}">${escapeHtml(s.name)}</option>`).join("");
  $("fSubject").innerHTML=state.subjects.map(s=>`<option value="${s.id}">${escapeHtml(s.name)}</option>`).join("");
}
async function loadData(){
  $("assessmentList").innerHTML='<div class="empty">일정을 불러오는 중입니다…</div>';
  const month=`${state.month.getFullYear()}-${pad(state.month.getMonth()+1)}`;
  const p=new URLSearchParams({grade:state.grade,class:state.classNo,month});
  try{
    state.all=await api(`/api/assessments?${p}`);
    applyFilters();
  }catch(e){
    state.all=[];state.filtered=[];renderAll();
    toast(e.message+" 데이터베이스 연결 상태를 확인하세요.");
  }
}
function applyFilters(){
  const q=$("searchInput").value.trim().toLowerCase(),sub=$("subjectFilter").value,from=$("fromFilter").value,to=$("toFilter").value;
  state.filtered=state.all.filter(a=>{
    const txt=`${a.title} ${a.description||""} ${a.subject||""}`.toLowerCase();
    const d=String(a.assessment_date).slice(0,10);
    return (!q||txt.includes(q))&&(!sub||String(a.subject_id)===sub)&&(!from||d>=from)&&(!to||d<=to);
  });
  renderAll();
}
function renderAll(){renderMonth();renderUrgent();renderList();}
function renderMonth(){
  const y=state.month.getFullYear(),m=state.month.getMonth();
  $("monthTitle").textContent=`${y}년 ${m+1}월`;
  const first=new Date(y,m,1),offset=(first.getDay()+6)%7,start=new Date(y,m,1-offset);
  let html=weekdays.map(d=>`<div class="weekday">${d}</div>`).join("");
  for(let i=0;i<42;i++){
    const d=new Date(start);d.setDate(start.getDate()+i);
    if(i>=35&&d.getMonth()!==m)break;
    const key=dateStr(d),today=key===dateStr(new Date()),other=d.getMonth()!==m;
    const events=state.filtered.filter(a=>String(a.assessment_date).slice(0,10)===key);
    html+=`<div class="day ${other?"other":""} ${today?"today":""}" data-date="${key}"><div class="day-number">${d.getDate()}</div>${events.slice(0,2).map(a=>`<div class="day-event ${dday(deadline(a))>=0&&dday(deadline(a))<=3?"urgent":""}" data-open="${a.id}" title="${escapeHtml(a.title)}">${escapeHtml(a.subject)} · ${escapeHtml(a.title)}</div>`).join("")}${events.length>2?`<div class="day-event">+${events.length-2}개 더</div>`:""}</div>`;
  }
  $("calendar").innerHTML=html;
  $("calendar").querySelectorAll("[data-open]").forEach(el=>el.addEventListener("click",e=>{e.stopPropagation();showDetail(el.dataset.open);}));
  $("calendar").querySelectorAll(".day").forEach(el=>el.addEventListener("click",()=>{const d=el.dataset.date;$("fromFilter").value=d;$("toFilter").value=d;applyFilters();}));
}
function renderUrgent(){
  const future=state.all.filter(a=>dday(deadline(a))>=0).sort((a,b)=>deadline(a).localeCompare(deadline(b)));
  const a=future[0];
  if(!a){$("urgentTitle").textContent="다가오는 수행평가가 없어요";$("urgentMeta").textContent="새로운 일정이 등록되면 이곳에 표시됩니다."; $("urgentDday").textContent="—";$("urgentCard").onclick=null;return;}
  $("urgentTitle").textContent=`${a.subject} · ${a.title}`;
  $("urgentMeta").textContent=`${deadline(a)===String(a.assessment_date).slice(0,10)?"평가":"제출"} ${pretty(deadline(a))}`;
  $("urgentDday").textContent=getDdayText(dday(deadline(a)));
  $("urgentCard").onclick=()=>showDetail(a.id);
}
function renderList(){
  $("resultCount").textContent=`${state.filtered.length}개`;
  if(!state.filtered.length){$("assessmentList").innerHTML='<div class="empty">표시할 수행평가가 없습니다.<br>검색 조건을 바꾸거나 다른 달을 확인해 보세요.</div>';return;}
  const sorted=[...state.filtered].sort((a,b)=>deadline(a).localeCompare(deadline(b)));
  $("assessmentList").innerHTML=sorted.map(a=>{
    const date=parseDate(a.assessment_date),n=dday(deadline(a));
    return `<article class="assessment-item" data-open="${a.id}"><div class="date-tile"><strong>${date.getDate()}</strong><span>${date.getMonth()+1}월</span></div><div class="item-info"><div class="item-subject">${escapeHtml(a.subject)}</div><h3>${escapeHtml(a.title)}</h3><p>${deadline(a)!==String(a.assessment_date).slice(0,10)?"제출":"평가"} ${pretty(deadline(a))} ${a.attachments?.length? " · 📎 자료 "+a.attachments.length+"개":""}</p></div><div class="item-dday">${n>=0?getDdayText(n):"지난 일정"}</div></article>`;
  }).join("");
  $("assessmentList").querySelectorAll("[data-open]").forEach(el=>el.addEventListener("click",()=>showDetail(el.dataset.open)));
}
async function showDetail(id){
  let a=state.all.find(x=>x.id===id);
  if(!a){try{a=await api(`/api/assessments/${id}`);}catch(e){return toast(e.message);}}
  $("detailBody").innerHTML=`<div class="detail-subject">${escapeHtml(a.subject||"수행평가")}</div><h2 class="detail-title">${escapeHtml(a.title)}</h2><div class="detail-meta"><div class="meta-box"><span>평가 날짜</span><strong>${pretty(a.assessment_date)}</strong></div><div class="meta-box"><span>제출 기한</span><strong>${pretty(a.due_at)}</strong></div></div><section class="detail-section"><h3>평가 내용</h3><p>${escapeHtml(a.description||"등록된 설명이 없습니다.")}</p></section><section class="detail-section"><h3>준비물 및 유의사항</h3><p>${escapeHtml(a.materials||"등록된 내용이 없습니다.")}</p></section><section class="detail-section"><h3>첨부 자료</h3><p>${a.attachments?.length?a.attachments.map(f=>`📎 ${escapeHtml(f.name||f.original_name)}`).join("<br>"):"첨부 자료가 없습니다."}</p></section>`;
  openDialog("detailDialog");
}
function renderClassChecks(selected=[]){
  $("classChecks").innerHTML=Array.from({length:24},(_,i)=>{const grade=Math.floor(i/8)+1,cl=i%8+1,id=i+1;return `<label class="class-check"><input type="checkbox" value="${id}" ${selected.includes(id)?"checked":""}> ${grade}학년 ${cl}반</label>`;}).join("");
}
async function refreshMe(){
  try{const d=await api("/api/auth/me");state.user=d.user;return d;}catch{return {user:null,googleConfigured:false};}
}
async function showTeacherPortal(){
  openDialog("teacherDialog");
  $("teacherContent").innerHTML='<div class="empty">로그인 상태를 확인하고 있습니다…</div>';
  const d=await refreshMe(),u=d.user;
  if(!u){
    $("teacherContent").innerHTML=`<div class="status-card"><strong>교사 계정 로그인</strong>Google 계정으로 로그인한 뒤 관리자의 승인을 받으면 수행평가를 등록할 수 있습니다.</div><div id="googleButton" class="google-wrap"></div>${d.googleConfigured?"":'<p class="small muted">Google 로그인을 사용하려면 Google Cloud에서 OAuth 클라이언트를 생성하고 GOOGLE_CLIENT_ID를 설정해야 합니다. 설정 방법은 README를 확인하세요.</p>'}`;
    if(d.googleConfigured&&window.google?.accounts?.id){
      google.accounts.id.initialize({client_id:d.googleClientId||"",callback:async response=>{try{await api("/api/auth/google",{method:"POST",body:JSON.stringify({credential:response.credential})});await showTeacherPortal();toast("로그인되었습니다.");}catch(e){toast(e.message);}}});
      google.accounts.id.renderButton($("googleButton"),{theme:"outline",size:"large",shape:"rectangular",text:"signin_with",locale:"ko"});
    }
    return;
  }
  if(u.role==="admin"){
    $("teacherContent").innerHTML=`<div class="status-card"><strong>관리자 · ${escapeHtml(u.name)}</strong>${escapeHtml(u.email)}<br>전체 공지와 교사 권한을 관리할 수 있습니다.</div><div class="admin-actions" style="margin-top:14px"><button id="createBtn" class="btn btn-primary">+ 수행평가 등록</button><button id="usersBtn" class="btn btn-quiet">교사 계정 관리</button><button id="logoutBtn" class="btn btn-quiet">로그아웃</button></div><div id="teacherAdminList"></div>`;
    $("createBtn").onclick=()=>openAssessmentForm();
    $("usersBtn").onclick=loadAdminUsers;
    $("logoutBtn").onclick=logout;
    return;
  }
  if(u.approvalStatus!=="approved"){
    const labels={pending:"승인 대기",rejected:"승인 거절",suspended:"권한 정지"};
    $("teacherContent").innerHTML=`<div class="status-card"><strong>${labels[u.approvalStatus]||"승인 필요"}</strong>${escapeHtml(u.name)} (${escapeHtml(u.email)})<br>관리자가 교사 계정을 승인해야 수행평가를 등록할 수 있습니다.</div><div class="admin-actions" style="margin-top:14px"><button id="applyBtn" class="btn btn-primary">승인 상태 확인</button><button id="logoutBtn" class="btn btn-quiet">로그아웃</button></div>`;
    $("applyBtn").onclick=async()=>{try{const x=await api("/api/teacher/apply",{method:"POST",body:"{}"});toast(x.message||"현재 승인 상태: "+x.status);}catch(e){toast(e.message);}};
    $("logoutBtn").onclick=logout;return;
  }
  $("teacherContent").innerHTML=`<div class="status-card"><strong>승인된 교사 · ${escapeHtml(u.name)}</strong>${escapeHtml(u.email)}</div><div class="admin-actions" style="margin-top:14px"><button id="createBtn" class="btn btn-primary">+ 수행평가 등록</button><button id="mineBtn" class="btn btn-quiet">내가 등록한 일정 보기</button><button id="logoutBtn" class="btn btn-quiet">로그아웃</button></div><div id="teacherAdminList"></div>`;
  $("createBtn").onclick=()=>openAssessmentForm();
  $("mineBtn").onclick=loadTeacherOwn;
  $("logoutBtn").onclick=logout;
}
async function loadAdminUsers(){
  try{
    const users=await api("/api/admin/teachers");
    $("teacherAdminList").innerHTML='<h3 style="font-size:14px;margin-top:22px">계정 및 승인 관리</h3><div class="admin-list">'+users.map(u=>`<div class="admin-row"><div><strong>${escapeHtml(u.display_name)}</strong><p>${escapeHtml(u.email)} · ${escapeHtml(u.role)} · ${escapeHtml(u.approval_status)}</p></div><div class="admin-actions"><button class="btn btn-primary" data-user="${u.id}" data-status="approved" data-role="teacher">승인</button><button class="btn btn-quiet" data-user="${u.id}" data-status="rejected" data-role="teacher">거절</button><button class="btn btn-quiet" data-user="${u.id}" data-status="suspended" data-role="teacher">정지</button></div></div>`).join("")+'</div>';
    $("teacherAdminList").querySelectorAll("[data-user]").forEach(b=>b.onclick=async()=>{try{await api(`/api/admin/teachers/${b.dataset.user}`,{method:"PATCH",body:JSON.stringify({approvalStatus:b.dataset.status,role:b.dataset.role})});toast("권한을 변경했습니다.");loadAdminUsers();}catch(e){toast(e.message);}});
  }catch(e){toast(e.message);}
}
async function loadTeacherOwn(){
  const u=state.user;
  const all=await api(`/api/assessments?grade=${state.grade}&class=${state.classNo}`);
  const mine=all.filter(a=>a.created_by===u.id);
  $("teacherAdminList").innerHTML='<h3 style="font-size:14px;margin-top:22px">내가 등록한 일정</h3><div class="admin-list">'+(mine.length?mine.map(a=>`<div class="admin-row"><div><strong>${escapeHtml(a.title)}</strong><p>${escapeHtml(a.subject)} · ${pretty(a.assessment_date)}</p></div><div class="admin-actions"><button class="btn btn-quiet" data-edit="${a.id}">수정</button><button class="btn btn-quiet" data-delete="${a.id}">삭제</button></div></div>`).join(""):'<div class="empty">현재 학급에 등록한 일정이 없습니다.</div>')+'</div>';
  $("teacherAdminList").querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>openAssessmentForm(all.find(a=>a.id===b.dataset.edit)));
  $("teacherAdminList").querySelectorAll("[data-delete]").forEach(b=>b.onclick=async()=>{if(!confirm("이 수행평가를 삭제할까요?"))return;try{await api(`/api/assessments/${b.dataset.delete}`,{method:"DELETE"});toast("삭제했습니다.");loadData();loadTeacherOwn();}catch(e){toast(e.message);}});
}
async function openAssessmentForm(a=null){
  closeDialog("teacherDialog");
  await loadSubjects();
  $("formTitle").textContent=a?"수행평가 수정":"수행평가 등록";
  $("editId").value=a?.id||"";
  $("fTitle").value=a?.title||"";
  $("fSubject").value=a?.subject_id||state.subjects[0]?.id||"";
  $("fDate").value=a?String(a.assessment_date).slice(0,10):dateStr(new Date());
  $("fDue").value=a?.due_at?String(a.due_at).slice(0,10):"";
  $("fDescription").value=a?.description||"";
  $("fMaterials").value=a?.materials||"";
  let ids=[];
  if(a?.classes)ids=a.classes.map(c=>(Number(c.grade)-1)*8+Number(c.class_number));
  else if(a?.id){try{const d=await api(`/api/assessments/${a.id}`);ids=d.classIds||[];}catch{}}
  renderClassChecks(ids);
  openDialog("formDialog");
}
$("assessmentForm").addEventListener("submit",async e=>{
  e.preventDefault();
  const classIds=[...$("classChecks").querySelectorAll("input:checked")].map(x=>Number(x.value));
  if(!classIds.length)return toast("대상 학급을 하나 이상 선택하세요.");
  const body={title:$("fTitle").value,subjectId:Number($("fSubject").value),assessmentDate:$("fDate").value,dueAt:$("fDue").value||null,description:$("fDescription").value,materials:$("fMaterials").value,classIds};
  const id=$("editId").value;
  try{
    await api(id?`/api/assessments/${id}`:"/api/assessments",{method:id?"PATCH":"POST",body:JSON.stringify(body)});
    closeDialog("formDialog");toast(id?"수행평가를 수정했습니다.":"수행평가를 등록했습니다.");showDashboard();
  }catch(err){toast(err.message);}
});
async function logout(){try{await api("/api/auth/logout",{method:"POST",body:"{}"});state.user=null;toast("로그아웃했습니다.");showTeacherPortal();}catch(e){toast(e.message);}}
$("enterBtn").onclick=()=>{state.grade=Number($("gradeSelect").value);state.classNo=Number($("classSelect").value);showDashboard();};
$("changeClassBtn").onclick=showPicker;
$("gradeSelect").onchange=()=>{state.grade=Number($("gradeSelect").value);};
$("classSelect").onchange=()=>{state.classNo=Number($("classSelect").value);};
$("teacherBtn").onclick=showTeacherPortal;
$("prevMonth").onclick=()=>{state.month=new Date(state.month.getFullYear(),state.month.getMonth()-1,1);loadData();};
$("nextMonth").onclick=()=>{state.month=new Date(state.month.getFullYear(),state.month.getMonth()+1,1);loadData();};
$("todayBtn").onclick=()=>{state.month=new Date(new Date().getFullYear(),new Date().getMonth(),1);loadData();};
$("searchInput").oninput=applyFilters;$("subjectFilter").onchange=applyFilters;$("fromFilter").onchange=applyFilters;$("toFilter").onchange=applyFilters;
$("resetFilters").onclick=()=>{$("searchInput").value="";$("subjectFilter").value="";$("fromFilter").value="";$("toFilter").value="";applyFilters();};
(async function init(){
  loadSavedClass();fillClasses();$("gradeSelect").value=state.grade;$("classSelect").value=state.classNo;
  await loadSubjects();
  // On first visit, show class selection. A saved selection still requires the user to enter.
})();
